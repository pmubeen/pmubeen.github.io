close all
clc
a=20;
e=[0,0.5,1.0,1.5];
b=[a*sqrt(1-e(1).^2),a*sqrt(1-e(2).^2),a*sqrt(e(3).^2-1),a*sqrt(e(4).^2-1)];
p=[a,(b(2)^2)/a,2*a,(b(4)^2)/a];
o1=0;
o2=0;
o3=0;
o4=0;
n=1;
j=0;
for t=0:0.01*pi:2*pi
    r=p(1)/(1+e(1)*cos(t));
    o1(n,1)=r*cos(t);
    o1(n,2)=r*sin(t);
    
    r=p(2)/(1+e(2)*cos(t));
    o2(n,1)=r*cos(t);
    o2(n,2)=r*sin(t);
    
    r=p(3)/(1+e(3)*cos(t));
    o3(n,1)=r*cos(t);
    o3(n,2)=r*sin(t);
    
    r=p(4)/(1+e(4)*cos(t));
    o4(n,1)=r*cos(t);
    o4(n,2)=r*sin(t);
    n=n+1;
end
plot(o1(:,1),o1(:,2));
hold on
plot(o2(:,1),o2(:,2));
hold on
plot(o3(:,1),o3(:,2));
hold on
plot(o4(:,1),o4(:,2),'k.');
axis equal
axis([-40 80 -30 30]);
legend('e=0','e=0.5','e=1.0','e=1.5');
fprintf('The semi-minor axis for e=0 is %f',b(1));
fprintf('\nThe semi-minor axis for e=0.5 is %f',b(2));
fprintf('\nThe semi-minor axis for e=1.0 is %f',b(3));
fprintf('\nThe semi-minor axis for e=1.5 is %f',b(4));