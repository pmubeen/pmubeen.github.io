close all
clc
GM = 6.67*10^-11*2e30;
e=[0.205,0.007,0.017,0.094,0.049,0.057,0.046,0.011,0.244];
a=([46+69.8,107.5+108.9,147.1+152.1,206.6+249.2,740.5+816.6,1352.6+1514.5,2741.3+3003.6,4444.5+4545.7,4436.8+7375.9]/2)*10^6;
b=[a(1)*sqrt(1-e(1).^2),a(2)*sqrt(1-e(2).^2),a(3)*sqrt(e(3).^2-1),a(4)*sqrt(e(4).^2-1),a(5)*sqrt(e(5).^2-1),a(6)*sqrt(e(6).^2-1),a(7)*sqrt(e(7).^2-1),a(8)*sqrt(e(8).^2-1),a(9)*sqrt(e(9).^2-1)];
p=[b(1).^2/a(1),b(2).^2/a(2),b(3).^2/a(3),b(4).^2/a(4),b(5).^2/a(5),b(6).^2/a(6),b(7).^2/a(7),b(8).^2/a(8),b(9).^2/a(9)];
o1=0;
o2=0;
o3=0;
o4=0;
o5=0;
o6=0;
o7=0;
o8=0;
o9=0;
n=1;
j=0;
for t=0:0.01*pi:2*pi
    r=p(1)/(1+e(1)*cos(t));
    o1(n,1)=r*cos(t);
    o1(n,2)=r*sin(t);
    
    r=p(2)/(1+e(2)*cos(t));
    o2(n,1)=r*cos(t);
    o2(n,2)=r*sin(t);
    
    r=p(3)/(1+e(3)*cos(t));
    o3(n,1)=r*cos(t);
    o3(n,2)=r*sin(t);
    
    r=p(4)/(1+e(4)*cos(t));
    o4(n,1)=r*cos(t);
    o4(n,2)=r*sin(t);
    
    r=p(5)/(1+e(5)*cos(t));
    o5(n,1)=r*cos(t);
    o5(n,2)=r*sin(t);

    r=p(6)/(1+e(6)*cos(t));
    o6(n,1)=r*cos(t);
    o6(n,2)=r*sin(t);
    
    r=p(7)/(1+e(7)*cos(t));
    o7(n,1)=r*cos(t);
    o7(n,2)=r*sin(t);

    r=p(8)/(1+e(8)*cos(t));
    o8(n,1)=r*cos(t);
    o8(n,2)=r*sin(t);
    
    r=p(9)/(1+e(9)*cos(t));
    o9(n,1)=r*cos(t);
    o9(n,2)=r*sin(t);
    n=n+1;
end
plot(o1(:,1),o1(:,2));
hold on
plot(o2(:,1),o2(:,2));
hold on
plot(o3(:,1),o3(:,2));
hold on
plot(o4(:,1),o4(:,2));
axis equal
legend('Mercury','Venus','Earth','Mars');
figure
plot(o5(:,1),o5(:,2));
hold on
plot(o6(:,1),o6(:,2));
hold on
plot(o7(:,1),o7(:,2));
hold on
plot(o8(:,1),o8(:,2));
hold on
plot(o9(:,1),o9(:,2));
axis equal
legend('Jupiter','Saturn','Neptune','Uranus','Pluto');
disp('The units are in seconds');
fprintf('The time period for Mercury is %f\n',sqrt(4*pi^2*((a(1)*10^3)^3/GM)));
fprintf('The time period for Venus is %f\n',sqrt(4*pi^2*((a(2)*10^3)^3/GM)));
fprintf('The time period for Earth is %f\n',sqrt(4*pi^2*((a(3)*10^3)^3/GM)));
fprintf('The time period for Mars is %f\n',sqrt(4*pi^2*((a(4)*10^3)^3/GM)));
fprintf('The time period for Jupiter is %f\n',sqrt(4*pi^2*((a(5)*10^3)^3/GM)));
fprintf('The time period for Saturn is %f\n',sqrt(4*pi^2*((a(6)*10^3)^3/GM)));
fprintf('The time period for Neptune is %f\n',sqrt(4*pi^2*((a(7)*10^3)^3/GM)));
fprintf('The time period for Uranus is %f\n',sqrt(4*pi^2*((a(8)*10^3)^3/GM)));
fprintf('The time period for Pluto is %f\n',sqrt(4*pi^2*((a(9)*10^3)^3/GM)));