clearvars
close all
%Use perhelion and aphelion

G = 6.67e-11; %grav constant
M = ; %approx Solar mass in kg
GM = G*M; % mu

Z  = @(t,x,y,vx,vy) [1 vx vy -GM*x/(sqrt(x^2 + y^2))^3 -GM*y/(sqrt(x^2+y^2))^3];    % equations of motion in 2D

a = ; %semi-major axis for Mars

%inital conditions of the orbit
x(1) = a;   % set satellite on the x axis
y(1) = 0;
vx(1) = 0;
vy(1) = sqrt(GM/a); % all velocity in the y-direction
t(1) = 0;

qVal = ; %final query point (orbital period in seconds)
h = ;  % step size
iterationN = round((qVal-t(1))/h);

soln = [t x y vx vy]; % solution - these are the values we are solving for

%uses RK4 method to solve for position and velocity
for i = 1:iterationN;
    
    t(i) = soln(i,1);
    x(i) = soln(i,2);
    y(i) = soln(i,3);
    vx(i) = soln(i,4);
    vy(i) = soln(i,5);
    
    k1 = Z( t(i),x(i),y(i),vx(i),vy(i) );
    k2 = Z( t(i) + h/2*k1(1), x(i)+ h/2*k1(2), y(i)+ h/2*k1(3), vx(i)+ h/2*k1(4), vy(i)+ h/2*k1(5) );
    k3 = Z( t(i) + h/2*k2(1), x(i)+ h/2*k2(2), y(i)+ h/2*k2(3), vx(i)+ h/2*k2(4), vy(i)+ h/2*k2(5));
    k4 = Z( t(i) + h, x(i)+ h*k3(2), y(i)+ h*k3(3), vx(i)+ h*k3(4), vy(i) + h*k3(5) );
    soln = [soln; soln(i,:) + h*(k1 +2*k2 + 2*k3 + k4)/6];
    
end

figure;
plot(x,y,'k-','linewidth',1.5)
xlabel('x'); ylabel('y'); box on;
set(gca,'fontsize',14);
axis equal