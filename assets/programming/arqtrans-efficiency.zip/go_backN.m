clear all;
clc;
for k=1:5
totalNbits=0; frameN=0;totalT=0; i=0;j=0;
RframeN=14400000/33-1;
while totalNbits<58982400||totalT<14400000
p(k)=1*10^(-k); %BER
Errorframe=randsrc(1,136,[0,1;(1-p(k)),p(k)]); %channel
Am=sum(Errorframe);
if Am==0
frameN=frameN+1;
totalT=totalT+33;
totalNbits=totalNbits+136;
i=i+1;
else
j=j+1;
A(j)=Am;
if i==0
totalT=totalT+2*33;
totalNbits=totalNbits+2*136;
i=0;
elseif i==1
totalT=totalT+4*33;
totalNbits=totalNbits+4*136;
i=0;
else
totalT=totalT+6*33;
totalNbits=totalNbits+6*136;
i=0;
end % if i==0
end % if Am==0
end %while
Eff_gobackN(k)=frameN/RframeN;%transmission efficiency
end %for
semilogy(Eff_gobackN,p)
legend('Go back N ARQ')
xlabel('Transmission efficiency')
ylabel('BER')
disp(Eff_gobackN(5));
