close all
clear all
clc

%Initialize 
%Establish the connection
try
    % Grab an existing instance of STK
    uiapp = actxGetRunningServer('STK11.application');
    root = uiapp.Personality2;
    checkempty = root.Children.Count;
    if checkempty == 0
        %If a Scenario is not open, create a new scenario
        uiapp.visible = 1;
        root.NewScenario('Satellite_Lifetime');
        scenario = root.CurrentScenario;
    else
        %If a Scenario is open, prompt the user to accept closing it or not
        rtn = questdlg({'Close the current scenario?',' ','(WARNING: If you have not saved your progress will be lost)'});
        if ~strcmp(rtn,'Yes')
            return
        else
            root.CurrentScenario.Unload
            uiapp.visible = 1;
            root.NewScenario('Satellite Lifetime');
            scenario = root.CurrentScenario;
        end
    end

catch
    % STK is not running, launch new instance
    % Launch a new instance of STK11 and grab it
    uiapp = actxserver('STK11.application');
    root = uiapp.Personality2;
    uiapp.visible = 1;
    root.NewScenario('Assignment3');
    scenario = root.CurrentScenario;
end
root.UnitPreferences.Item('DateFormat').SetCurrentUnit('UTCG');

%set scenario time period and animation period
root.CurrentScenario.SetTimePeriod('1 July 2019 12:00:00.000','31 July 2019 23:59:59.000');
root.CurrentScenario.Epoch = '1 Jul 2015 12:00:00.000';
root.CurrentScenario.Animation.EnableAnimCycleTime = true;
root.CurrentScenario.Animation.AnimCycleType = 'eEndTime';
root.CurrentScenario.Animation.AnimCycleTime = '31 Jul 2019 12:00:00.000';
root.CurrentScenario.Animation.StartTime = '1 Jul 2019 12:00:00.000';
root.CurrentScenario.Animation.EnableAnimCycleTime = false;

root.Rewind();

scenario.SetTimePeriod('1 July 2019 12:00:00.000','31 July 2019 23:59:59.000');
scenario.StartTime = '1 July 2019 12:00:00.000';
scenario.StopTime = '31 July 2019 23:59:59.000';
satellite = scenario.Children.New('eSatellite','AssignSat');
keplerian = satellite.Propagator.InitialState.Representation.ConvertTo('eOrbitStateClassical'); % Use the Classical Element interface
keplerian.SizeShapeType = 'eSizeShapeAltitude';  % Changes from Ecc/Inc to Perigee/Apogee Altitude
keplerian.LocationType = 'eLocationTrueAnomaly'; % Makes sure True Anomaly is being used
keplerian.Orientation.AscNodeType = 'eAscNodeLAN'; % Use LAN instead of RAAN for data entry
% Assign the perigee and apogee altitude values:
keplerian.SizeShape.PerigeeAltitude = 401;      % km
keplerian.SizeShape.ApogeeAltitude = 408;       % km
% Assign the other desired orbital parameters:
keplerian.Orientation.Inclination = 51.6395;         % deg
keplerian.Orientation.ArgOfPerigee = 93.5209;        % deg
keplerian.Orientation.AscNode.Value = 274.3643;       % deg
keplerian.Location.Value = 180;                 % deg
% Apply the changes made to the satellite's state and propagate:
satellite.Propagator.InitialState.Representation.Assign(keplerian);
satellite.Propagator.Propagate;
propagate.Properties.Color = 'Cyan';
root.ExecuteCommand('SetLifetime */Satellite/AssignSat DragCoeff 2.2 ReflectCoeff 1 DragArea 0.1 SunArea 0.1 Mass 1 DecayAltitude 100 FluxSigmaLevel 1 2ndOrder On Rotate On Graphics Off DensityModel Jacchia71');
facility = scenario.Children.New('eFacility','York_University');
facility.Position.AssignGeodetic(43.7735,-79.5019,0);
access = satellite.GetAccessToObject(facility);
access.ComputeAccess;

accessDP = access.DataProviders.Item('Access Data').Exec(scenario.StartTime,scenario.StopTime);
accessIntervals = access.ComputedAccessIntervalTimes;

for i = 1:1:accessIntervals.Count
   [start,stop] = accessIntervals.GetInterval(i-1) 
end

satDP2 = satellite.DataProviders.Item('Classical Elements').Group.Item('J2000').Exec(scenario.StartTime,scenario.StopTime,1);
satSMA = satDP2.DataSets.GetDataSetByName('Semi-major Axis').GetValues;
satECC = satDP2.DataSets.GetDataSetByName('Eccentricity').GetValues;
satINC = satDP2.DataSets.GetDataSetByName('Inclination').GetValues;
%satASC = satDP2.DataSets.GetDataSetByName('Lon. Ascn. Node').GetValues;
%satAGP = satDP2.DataSets.GetDataSetByName('Argument of Periapsis').GetValues;
satTRA = satDP2.DataSets.GetDataSetByName('True Anomaly').GetValues;
figure;plot(cell2mat(satSMA));
title('Semi Major Axis');
figure;
plot(cell2mat(satECC));
title('Eccentricity');
figure;
plot(cell2mat(satINC));
title('Inclination');
%plot(cell2mat(satASC));
%title('Longitude of Ascending Node');
%plot(cell2mat(satAGP));
%title('Argument of Periapsis');
figure;
plot(cell2mat(satTRA));
title('True Anomaly');

