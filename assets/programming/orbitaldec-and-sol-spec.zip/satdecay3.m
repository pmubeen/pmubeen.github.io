clc;
clear all
close all

satm = 70;
k = 1.38e-23;
T = 100;
satCA = 1.5;
Cd = 2;
hi = 250e3;
rhoi = 3.25e-10;
H = 9.12e3;
G = 6.67e-11;
Me = 5.97e24;
Re = 6.371e6;
mu = G*Me;
n = 10;
xval = 1:10;

Et = zeros(1,n);
h = zeros(1,n);
v = zeros(1,n);
rho = zeros(1,n);
Fd = zeros(1,n);
Wd = zeros(1,n);
tp = zeros(1,n);
L = zeros(1,n);

h(1,1) = hi+Re;
Et(1,1) = -(mu*satm)/(2*h(1,1));
v(1,1) = sqrt(mu/h(1,1));
rho(1,1) = rhoi;
Fd(1,1) = (1/2)*rho(1,1)*satCA*Cd*v(1,1)^2;
Wd(1,:) = Fd(1,1)*(2*pi*h(1,1));
tp(1,1) = 2*pi*sqrt((h(1,1)^3)/mu);
dr = (-rho(1,1)*((Cd*satCA)/satm)*sqrt(mu*h(1,1)))/tp(1,1);
L(1,1) = -H/dr;

for i = 2:10
    Et(1,i) = Et(1,i-1)+Wd(1,i-1);
    h(1,i) = -(mu*satm)/(2*Et(1,i));
    v(1,i) = sqrt(mu/h(1,i));
    tp(1,i) = 2*pi*sqrt((h(1,i)^3)/mu);
    dt = (tp(1,i-1)-tp(1,i))/tp(1,i-1);
    rho(1,i) = dt/(-3*pi*h(1,i)*(Cd*satCA)/satm);
    Fd(1,i) = (1/2)*rho(1,i)*satCA*Cd*v(1,i)^2;
    Wd(1,i) = Fd(1,i)*(2*pi*h(1,i));
    dr = (-rho(1,i)*((Cd*satCA)/satm)*sqrt(mu*h(1,i)))/tp(1,i);
    L(1,i) = -H/dr;
end
h = (h./1000)-6371;
L = tp./3600;
figure
plot(h,L);
title("Time of Decay");
xlabel("Altitude (Km)");
ylabel("Time (Hrs)");
figure
plot(h,-rho);
title("Atmospheric Density");
ylabel("Density (kgm^-3");
xlabel("Altitude (Km)");