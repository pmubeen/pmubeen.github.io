clear all
close all

%For constant density shear stress and variable density shear
%stress and the error between them>>

d1 = 815; %density of ice sheet near the surface
p1 = 10^5; %surface pressure
di = 916.7; %density of pure ice
ci =  1.2*10^(-10); %compressibility of ice
st1 = 0; %shear stress at top of the layer 1
g = 9.81; %gravitational acceleration
dz = 50; %ice sheet width
a = deg2rad(10); %slope of the sheet
sb1 = d1*g*dz*sin(a)+st1;%shear stress at the bottom of layer 1
z = 1; %partition no. Total partitions are 3000/50 = 60 partitions 
sbnc = zeros(60,1); %zeros column vector to fill with all values of constant density shear stress
sbnv = zeros(60,1); %zeros column vector to fill with all values of variable density shear stress
pbn = zeros(60,1); %zeros column vector to fill with all values of variable pressure
dbn = zeros(60,1); %zeros column vector to fill with all values of variable density
error = zeros(60,1); %zeros column vector for percent error
sbnc(1,1) = sb1;%initial value of constant shear stress
sbnv(1,1) = sb1;%inital value of variable shear stress
pbn(1,1) = p1;%initial value of pressure
dbn(1,1) = d1;%initial value of density
while z < 61
    sbnc(z+1,1) = d1*g*dz*sin(a)+sbnc(z,1);
    pbn((z+1),1) = pbn(z,1)+dbn(z,1)*g*dz*cos(a);
    dbn((z+1),1) = ((1-ci*(pbn((z+1),1)-p1))/916.7+(1/d1-(1-ci*(pbn((z+1),1)-p1))/916.7)*(p1/pbn((z+1),1)))^(-1);
    sbnv(z+1,1) = dbn(z+1)*g*dz*sin(a)+sbnv(z,1);
    error(z+1,1) = (abs(sbnc(z+1)-sbnv(z+1))/sbnv(z+1))*100;
    z = z+1; 
end
%plotting shear stresses
z = 0:50:3000;
plot(sbnc,z,'k--');
hold
plot(sbnv,z,'b.');
hold
title('Stresses of icesheet in depth');
legend('Shear Stress (Constant density)','Shear Stress (variable density)');
ylabel('depth (m)');
xlabel('Stress (pa)');
%plotting error
figure;
plot(z,error);
ylim([0,100]);
xlabel('depth (m)');
ylabel('Error (%)');
title('Percent error between Shear Stresses (constant density & variable density resp)');

%For fracturing level with different angles>>

a = deg2rad(5:1:20); %slope of the sheet (a goes from 5 to 20 in increments of 1)
sbnv = zeros(60,16); %zeros matrix to fill with all values of variable density shear stress
pbn = zeros(60,16); %zeros matrix to fill with all values of variable pressure
dbn = zeros(60,16); %zeros matrix to fill with all values of variable density
pbn(1,:) = p1;%initial value of pressure
dbn(1,:) = d1;%initial value of density
depth=zeros(1,16); % zeros vector for the depth
t=0:50:3000;
for i=1:1:16
    sb1 = d1*g*dz*sin(a(i))+st1; %initial slope
    sbnv(1,i)=sb1; % assigning initial value to the stresses
   for z=1:1:60
    pbn((z+1),i) = pbn(z,i)+dbn(z,i)*g*dz*cos(a(i));
    dbn((z+1),i) = ((1-ci*(pbn((z+1),i)-p1))/916.7+(1/d1-(1-ci*(pbn((z+1),i)-p1))/916.7)*(p1/pbn((z+1),i)))^(-1);
    sbnv((z+1),i) = dbn(z+1,i)*g*dz*sin(a(i))+sbnv(z,i);
    if abs(2*10^6-sbnv(z+1,i))<57095 && depth(i)==0 %the difference between the stress and fracturing level <19kpa gives closest val to threshold
        depth(i)=(z+1)*50; %adding the facturing level depth to vector and converting it to depth in m
    end
   end
end
%the plot
figure
plot(rad2deg(a),depth);
ylabel('depth (m)');
xlabel('angle (deg)');
title('Fracturing level depth with changing slope');
%ylim([2300,2700]);