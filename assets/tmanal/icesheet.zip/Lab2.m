clear all
close all
d1 = 815; %density of ice sheet near the surface
p1 = 10^5; %surface pressure
di = 916.7; %density of pure ice
ci =  1.2*10^(-10); %compressibility of ice
st1 = 0; %shear stress at top of the layer 1
g = 9.81; %gravitational acceleration
dz = 50; %ice sheet width
a = deg2rad(10); %slope of the sheet
sb1 = d1*g*dz*sin(a)+st1;%shear stress at the bottom of layer 1
z = 1; %partition no. Total partitions are 3000/50 = 60 partitions 
sbnc = zeros(60,1); %zeros column vector to fill with all values of constant density shear stress
sbnv = zeros(60,1); %zeros column vector to fill with all values of variable density shear stress
pbn = zeros(60,1); %zeros column vector to fill with all values of variable pressure
dbn = zeros(60,1); %zeros column vector to fill with all values of variable density
error = zeros(60,1); %zeros column vector for percent error
sbnc(1,1) = sb1;%initial value of constant shear stress
sbnv(1,1) = sb1;%inital value of variable shear stress
pbn(1,1) = p1;%initial value of pressure
dbn(1,1) = d1;%initial value of density
while z < 61
    sbnc(z+1,1) = d1*g*dz*sin(a)+sbnc(z,1);
    pbn((z+1),1) = pbn(z,1)+dbn(z,1)*g*dz*cos(a);
    dbn((z+1),1) = ((1-ci*(pbn((z+1),1)-p1))/916.7+(1/d1-(1-ci*(pbn((z+1),1)-p1))/916.7)*(p1/pbn((z+1),1)))^(-1);
    sbnv(z+1,1) = dbn(z+1)*g*dz*sin(a)+sbnv(z,1);
    error(z+1,1) = (abs(sbnc(z+1)-sbnv(z+1))/sbnv(z+1))*100;
    z = z+1; 
end
%plotting shear stresses
z = 0:50:3000;
plot(sbnc,z,'k--');
hold
plot(sbnv,z,'b.');
hold
title('Stresses of icesheet in depth');
legend('Shear Stress (Constant density)','Shear Stress (variable density)');
ylabel('depth (m)');
xlabel('Stress (pa)');
%plotting error
figure;
plot(z,error);
ylim([0,100]);
xlabel('depth (m)');
ylabel('Error (%)');
title('Percent error between Shear Stresses (constant density & variable density resp)');