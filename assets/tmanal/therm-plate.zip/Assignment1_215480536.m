%This code has been written by Mubeen Padaniya (modified from Prof's code). Please do not copy without
%prior permission from the author
clear
clc
clf
close all
% domain discretization
alpha = 5.3e-4;
xmin = 0;
xmax = 0.8;
M = 21;
N = 41;
time_steps=5;
dx = (xmax-xmin)/(N-1);
x = xmin:dx:xmax;
dt = 12;
tmax = dt*time_steps;
t = 0:dt:tmax;
% problem initialization
tmpLC = 221;
tmpT = 180;
tmpR = 154;
% solving the problem
r = alpha*dt/(dx^2); % for stability, must be 0.5 or less
tmp = ones(M,N,6)*4;
tmp(1,:,1) = tmpT;
tmp(:,N,1) = tmpR;
tmp(M,1,1) = tmpLC;
for p = 2:6 % for time steps
    for i = 1:M % for space steps
        for j = 1:N 
            %for each case
            if i == 1 && j>1 && j<N
                tmp(i,j,p)=r*(tmp(i+1,j,p-1)+tmp(i,j+1,p-1)+tmp(i,j-1,p-1)-3*tmp(i,j,p-1))+tmp(i,j,p-1);
            elseif i == M && j>1 && j<N
                tmp(i,j,p)=r*(tmp(i-1,j,p-1)+tmp(i,j+1,p-1)+tmp(i,j-1,p-1)-3*tmp(i,j,p-1))+tmp(i,j,p-1);
            elseif j == 1 && i>1 && i<M
                tmp(i,j,p)=r*(tmp(i+1,j,p-1)+tmp(i-1,j,p-1)+tmp(i,j+1,p-1)-3*tmp(i,j,p-1))-tmp(i,j,p-1);
            elseif j == N && i>1 && i<M
                tmp(i,j,p)=r*(tmp(i+1,j,p-1)+tmp(i-1,j,p-1)+tmp(i,j-1,p-1)-3*tmp(i,j,p-1))-tmp(i,j,p-1);
            elseif j == 1 && i == 1
                tmp(i,j,p)=r*(tmp(i+1,j,p-1)+tmp(i,j+1,p-1)-2*tmp(i,j,p-1))+tmp(i,j,p-1);
            elseif j == N && i == 1
                tmp(i,j,p)=r*(tmp(i+1,j,p-1)+tmp(i,j-1,p-1)-2*tmp(i,j,p-1))+tmp(i,j,p-1);
            elseif i == M && j == 1
                tmp(i,j,p)=r*(tmp(i-1,j,p-1)+tmp(i,j+1,p-1)-2*tmp(i,j,p-1))+tmp(i,j,p-1);
            elseif i == M && j == N
                tmp(i,j,p)=r*(tmp(i-1,j,p-1)+tmp(i,j-1,p-1)-2*tmp(i,j,p-1))+tmp(i,j,p-1);
            else
                tmp(i,j,p)=r*(tmp(i+1,j,p-1)+tmp(i-1,j,p-1)+tmp(i,j+1,p-1)+tmp(i,j-1,p-1)-4*tmp(i,j,p-1))+tmp(i,j,p-1);
            end
        end
    end
end
for t=1:6
    q=0;
    figure;
    contourf(tmp(:,:,t),10);
    xlabel('1 x unit = 2cm')
    ylabel('1 y unit = 2cm')

end